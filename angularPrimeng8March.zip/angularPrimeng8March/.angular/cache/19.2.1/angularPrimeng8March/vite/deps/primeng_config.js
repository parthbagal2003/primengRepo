import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-VZ3VT7OM.js";
import "./chunk-WWFGDI3Q.js";
import "./chunk-T3E6ERL3.js";
import "./chunk-P2MEMLSL.js";
import "./chunk-WDMUDEB6.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
